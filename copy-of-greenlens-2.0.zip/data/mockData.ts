
import type { User, Report, LeaderboardUser } from '../types';

const generateReports = (userId: string, count: number): Report[] => {
  const reports: Report[] = [];
  const wasteTypes: Report['wasteType'][] = ['Plastic', 'Paper', 'Organic', 'Glass', 'Metal'];
  const statuses: Report['status'][] = ['Verified', 'Cleaned', 'Pending'];
  for (let i = 1; i <= count; i++) {
    reports.push({
      id: `${userId}-report-${i}`,
      userId,
      imageUrl: `https://picsum.photos/seed/${userId}${i}/400/300`,
      location: { lat: 34.0522 - (i * 0.01), lng: -118.2437 + (i * 0.01) },
      wasteType: wasteTypes[i % wasteTypes.length],
      confidence: 80 + (i % 20),
      note: `Found this near the park entrance. Mostly ${wasteTypes[i % wasteTypes.length]}.`,
      timestamp: new Date(Date.now() - i * 24 * 60 * 60 * 1000),
      status: statuses[i % statuses.length],
    });
  }
  return reports;
};

export const mockUsers: User[] = [
  {
    id: 'user-1',
    name: 'Alex Green',
    email: 'alex.green@example.com',
    avatarUrl: `https://i.pravatar.cc/150?u=user-1`,
    greenUnits: 1250,
    reports: generateReports('user-1', 5),
  },
  {
    id: 'user-2',
    name: 'Bella Terra',
    email: 'bella.terra@example.com',
    avatarUrl: `https://i.pravatar.cc/150?u=user-2`,
    greenUnits: 3200,
    reports: generateReports('user-2', 8),
  },
    {
    id: 'user-3',
    name: 'Carlos Sol',
    email: 'carlos.sol@example.com',
    avatarUrl: `https://i.pravatar.cc/150?u=user-3`,
    greenUnits: 2100,
    reports: generateReports('user-3', 12),
  },
];

export const mockLeaderboard: LeaderboardUser[] = [
  { id: 'user-2', name: 'Bella Terra', avatarUrl: `https://i.pravatar.cc/150?u=user-2`, greenUnits: 3200, rank: 1 },
  { id: 'user-3', name: 'Carlos Sol', avatarUrl: `https://i.pravatar.cc/150?u=user-3`, greenUnits: 2100, rank: 2 },
  { id: 'user-1', name: 'Alex Green', avatarUrl: `https://i.pravatar.cc/150?u=user-1`, greenUnits: 1250, rank: 3 },
  { id: 'user-4', name: 'Diana River', avatarUrl: `https://i.pravatar.cc/150?u=user-4`, greenUnits: 980, rank: 4 },
  { id: 'user-5', name: 'Ethan Stone', avatarUrl: `https://i.pravatar.cc/150?u=user-5`, greenUnits: 750, rank: 5 },
];

export const mockOrgReports: Report[] = [
    ...generateReports('user-2', 3),
    ...generateReports('user-3', 2)
].map((report, index) => ({...report, id: `org-report-${index}`, status: 'Pending' as const})).sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
