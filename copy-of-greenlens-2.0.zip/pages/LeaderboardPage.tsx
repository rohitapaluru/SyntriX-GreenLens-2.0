import React from 'react';
import { mockLeaderboard } from '../data/mockData';
import LeaderboardItem from '../components/LeaderboardItem';

const LeaderboardPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-6 text-center">Top Reporters Leaderboard</h1>
      <ul className="space-y-4">
        {mockLeaderboard.map(user => (
          <LeaderboardItem key={user.id} user={user} />
        ))}
      </ul>
    </div>
  );
};

export default LeaderboardPage;
