import React, { useEffect, useRef, useState } from 'react';
import { mockUsers } from '../data/mockData';
import type { Report } from '../types';
import Button from '../components/Button';

// Use a global declaration for the Leaflet object from the CDN
declare const L: any;

const statusColors: { [key in Report['status']]: { text: string, bg: string } } = {
  Pending: { text: 'text-amber-800', bg: 'bg-amber-100' },
  Verified: { text: 'text-sky-800', bg: 'bg-sky-100' },
  Cleaned: { text: 'text-emerald-800', bg: 'bg-emerald-100' },
};

const MapPage: React.FC = () => {
  const mapRef = useRef<any>(null);
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const userLocationMarkerRef = useRef<any>(null);
  const allReports = mockUsers.flatMap(user => user.reports);

  const [locationError, setLocationError] = useState<string | null>(null);

  const findUserLocation = () => {
    if (!navigator.geolocation) {
      setLocationError("Geolocation is not supported by your browser.");
      return;
    }
    
    setLocationError(null);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        
        if (mapRef.current) {
          // Center map on user's location and zoom in
          mapRef.current.setView([latitude, longitude], 13);

          // Custom animated icon for user location
          const userIconHtml = `
            <div class="relative flex items-center justify-center w-6 h-6">
              <div class="absolute w-full h-full bg-blue-500 rounded-full animate-ping opacity-75"></div>
              <div class="relative w-3 h-3 bg-blue-600 rounded-full border-2 border-white shadow-md"></div>
            </div>
          `;
          const userIcon = L.divIcon({
            html: userIconHtml,
            className: 'bg-transparent border-0',
            iconSize: [24, 24],
            iconAnchor: [12, 12],
            popupAnchor: [0, -12]
          });

          // Remove old marker if it exists to prevent duplicates
          if (userLocationMarkerRef.current) {
            userLocationMarkerRef.current.remove();
          }

          // Add new marker and store its reference
          userLocationMarkerRef.current = L.marker([latitude, longitude], { icon: userIcon }).addTo(mapRef.current);
          userLocationMarkerRef.current.bindPopup("<b>You are here!</b>").openPopup();
        }
      },
      (error) => {
        console.error("Geolocation error:", error);
        setLocationError(`Could not get location: ${error.message}.`);
      }
    );
  };

  useEffect(() => {
    if (typeof L === 'undefined' || !mapContainerRef.current) {
        return;
    }

    if (!mapRef.current) {
      // Initialize map with a default view
      mapRef.current = L.map(mapContainerRef.current).setView([34.05, -118.24], 11);

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
      }).addTo(mapRef.current);

      // Plot all the waste reports
      allReports.forEach(report => {
        const marker = L.marker([report.location.lat, report.location.lng]).addTo(mapRef.current);
        const statusStyle = statusColors[report.status];
        const popupContent = `
            <div class="font-sans">
                <img src="${report.imageUrl}" alt="${report.wasteType}" class="w-full h-32 object-cover rounded-t-lg" />
                <div class="p-3">
                    <h3 class="font-bold text-lg text-slate-800">${report.wasteType}</h3>
                    <div class="mt-2 flex justify-between items-center">
                        <span class="text-sm text-slate-500">Confidence: ${report.confidence}%</span>
                        <span class="px-2 py-1 text-xs font-semibold rounded-full ${statusStyle.bg} ${statusStyle.text}">
                            ${report.status}
                        </span>
                    </div>
                </div>
            </div>
        `;
        marker.bindPopup(popupContent);
      });

      // Attempt to find the user's location on initial load
      findUserLocation();
    }

    return () => {
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
    };
  }, [allReports]);

  return (
    <div>
      <div className="flex flex-col sm:flex-row justify-between sm:items-center mb-4 gap-4">
        <h1 className="text-3xl font-bold">Waste Hotspots Map</h1>
        <Button onClick={findUserLocation} size="sm">
          Find My Location
        </Button>
      </div>
       {locationError && <p className="text-rose-500 mb-4 bg-rose-100 dark:bg-rose-900/50 p-3 rounded-lg text-center">{locationError}</p>}
      <div className="bg-white dark:bg-slate-800 rounded-xl shadow-lg p-2">
        <div ref={mapContainerRef} className="h-[600px] w-full rounded-lg z-10" />
      </div>
    </div>
  );
};

export default MapPage;
