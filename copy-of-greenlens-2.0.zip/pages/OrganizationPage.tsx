// FIX: Replaced placeholder content with the OrganizationPage component implementation.
import React, { useState } from 'react';
import { mockOrgReports } from '../data/mockData';
import type { Report } from '../types';
import Button from '../components/Button';

const statusColors: { [key in Report['status']]: string } = {
  Pending: 'bg-amber-100 text-amber-800 dark:bg-amber-900/50 dark:text-amber-300',
  Verified: 'bg-sky-100 text-sky-800 dark:bg-sky-900/50 dark:text-sky-300',
  Cleaned: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-300',
};

const OrgReportCard: React.FC<{ report: Report; onUpdateStatus: (id: string, status: 'Verified' | 'Cleaned') => void; }> = ({ report, onUpdateStatus }) => {
    return (
        <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md overflow-hidden flex flex-col">
            <img src={report.imageUrl} alt={`Waste report for ${report.wasteType}`} className="w-full h-48 object-cover" />
            <div className="p-5 flex-grow flex flex-col">
                <div className="flex justify-between items-start">
                    <h3 className="text-xl font-bold text-slate-800 dark:text-slate-100">{report.wasteType}</h3>
                    <span className={`px-3 py-1 text-xs font-semibold rounded-full ${statusColors[report.status]}`}>
                        {report.status}
                    </span>
                </div>
                <p className="text-slate-500 dark:text-slate-400 mt-1">Confidence: {report.confidence}%</p>
                {report.note && <p className="text-slate-600 dark:text-slate-300 mt-2 italic">"{report.note}"</p>}
                <p className="text-sm text-slate-400 dark:text-slate-500 mt-4">
                    Reported on {report.timestamp.toLocaleDateString()}
                </p>
                <div className="mt-auto pt-4 flex gap-2">
                    {report.status === 'Pending' && (
                        <Button size="sm" variant="secondary" className="w-full" onClick={() => onUpdateStatus(report.id, 'Verified')}>
                            Verify
                        </Button>
                    )}
                     {report.status === 'Verified' && (
                        <Button size="sm" className="w-full" onClick={() => onUpdateStatus(report.id, 'Cleaned')}>
                            Mark as Cleaned
                        </Button>
                    )}
                </div>
            </div>
        </div>
    );
};


const OrganizationPage: React.FC = () => {
    const [reports, setReports] = useState<Report[]>(mockOrgReports);

    const handleUpdateStatus = (reportId: string, newStatus: 'Verified' | 'Cleaned') => {
        setReports(currentReports =>
            currentReports.map(report =>
                report.id === reportId ? { ...report, status: newStatus } : report
            )
        );
    };
    
    const pendingReports = reports.filter(r => r.status === 'Pending');
    const verifiedReports = reports.filter(r => r.status === 'Verified');
    const cleanedReports = reports.filter(r => r.status === 'Cleaned');

    return (
        <div className="space-y-12">
            <div>
                <h2 className="text-2xl font-bold mb-4">Pending Verification ({pendingReports.length})</h2>
                {pendingReports.length > 0 ? (
                    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                        {pendingReports.map(report => (
                            <OrgReportCard key={report.id} report={report} onUpdateStatus={handleUpdateStatus} />
                        ))}
                    </div>
                ) : (
                    <p className="text-slate-500 p-8 text-center bg-white dark:bg-slate-800 rounded-xl">No pending reports to review.</p>
                )}
            </div>

             <div>
                <h2 className="text-2xl font-bold mb-4">Verified & Awaiting Cleanup ({verifiedReports.length})</h2>
                {verifiedReports.length > 0 ? (
                    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                        {verifiedReports.map(report => (
                            <OrgReportCard key={report.id} report={report} onUpdateStatus={handleUpdateStatus} />
                        ))}
                    </div>
                ) : (
                    <p className="text-slate-500 p-8 text-center bg-white dark:bg-slate-800 rounded-xl">No verified reports awaiting cleanup.</p>
                )}
            </div>

            <div>
                <h2 className="text-2xl font-bold mb-4">Completed ({cleanedReports.length})</h2>
                 {cleanedReports.length > 0 ? (
                    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 opacity-70">
                        {cleanedReports.map(report => (
                           <OrgReportCard key={report.id} report={report} onUpdateStatus={handleUpdateStatus} />
                        ))}
                    </div>
                 ) : (
                    <p className="text-slate-500 p-8 text-center bg-white dark:bg-slate-800 rounded-xl">No reports have been marked as cleaned yet.</p>
                 )}
            </div>
        </div>
    );
};

export default OrganizationPage;
