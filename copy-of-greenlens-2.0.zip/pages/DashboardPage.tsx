import React from 'react';
import type { User } from '../types';
import ReportCard from '../components/ReportCard';

interface DashboardPageProps {
  user: User;
}

const DashboardPage: React.FC<DashboardPageProps> = ({ user }) => {
  return (
    <div>
      <div className="flex items-center space-x-4 mb-8">
        <img src={user.avatarUrl} alt={user.name} className="h-24 w-24 rounded-full ring-4 ring-offset-2 ring-offset-slate-50 dark:ring-offset-slate-900 ring-emerald-500" />
        <div>
          <h1 className="text-3xl font-bold">{user.name}</h1>
          <p className="text-xl font-semibold text-emerald-500 dark:text-emerald-400">{user.greenUnits.toLocaleString()} GreenUnits</p>
        </div>
      </div>

      <h2 className="text-2xl font-bold mb-4">My Recent Reports</h2>
      {user.reports.length > 0 ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {user.reports.sort((a,b) => b.timestamp.getTime() - a.timestamp.getTime()).map(report => (
            <ReportCard key={report.id} report={report} />
          ))}
        </div>
      ) : (
        <div className="text-center py-12 bg-white dark:bg-slate-800 rounded-xl">
          <p className="text-slate-500">You haven't submitted any reports yet.</p>
        </div>
      )}
    </div>
  );
};

export default DashboardPage;
