import React from 'react';
import type { Report } from '../types';

interface ReportCardProps {
  report: Report;
}

const statusColors: { [key in Report['status']]: string } = {
  Pending: 'bg-amber-100 text-amber-800 dark:bg-amber-900/50 dark:text-amber-300',
  Verified: 'bg-sky-100 text-sky-800 dark:bg-sky-900/50 dark:text-sky-300',
  Cleaned: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-300',
};

const ReportCard: React.FC<ReportCardProps> = ({ report }) => {
  return (
    <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md overflow-hidden transform hover:scale-105 transition-transform duration-300 group">
      <div className="overflow-hidden">
        <img src={report.imageUrl} alt={`Waste report for ${report.wasteType}`} className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300" />
      </div>
      <div className="p-5">
        <div className="flex justify-between items-start">
          <h3 className="text-xl font-bold text-slate-800 dark:text-slate-100">{report.wasteType}</h3>
          <span className={`px-3 py-1 text-xs font-semibold rounded-full ${statusColors[report.status]}`}>
            {report.status}
          </span>
        </div>
        <p className="text-slate-500 dark:text-slate-400 mt-1">Confidence: {report.confidence}%</p>
        {report.note && <p className="text-slate-600 dark:text-slate-300 mt-2 italic">"{report.note}"</p>}
        <p className="text-sm text-slate-400 dark:text-slate-500 mt-4">
          Reported on {report.timestamp.toLocaleDateString()}
        </p>
      </div>
    </div>
  );
};

export default ReportCard;