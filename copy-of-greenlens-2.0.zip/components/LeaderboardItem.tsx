import React from 'react';
import type { LeaderboardUser } from '../types';

interface LeaderboardItemProps {
  user: LeaderboardUser;
}

const LeaderboardItem: React.FC<LeaderboardItemProps> = ({ user }) => {
  const rankColor = (rank: number) => {
    if (rank === 1) return 'bg-gradient-to-br from-amber-400 to-yellow-500 text-white shadow-lg shadow-yellow-500/30';
    if (rank === 2) return 'bg-gradient-to-br from-slate-300 to-slate-400 text-slate-800 shadow-lg shadow-slate-500/30';
    if (rank === 3) return 'bg-gradient-to-br from-amber-600 to-orange-700 text-white shadow-lg shadow-orange-700/30';
    return 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300';
  };

  return (
    <li className="flex items-center p-4 bg-white dark:bg-slate-800 rounded-xl shadow-md hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-all duration-200 hover:shadow-lg">
      <div className={`flex items-center justify-center w-12 h-12 rounded-lg font-bold text-lg ${rankColor(user.rank)}`}>
        {user.rank}
      </div>
      <img src={user.avatarUrl} alt={user.name} className="h-14 w-14 rounded-full mx-4 ring-2 ring-offset-2 ring-offset-white dark:ring-offset-slate-800 ring-emerald-400" />
      <div className="flex-grow">
        <p className="font-semibold text-lg text-slate-800 dark:text-slate-100">{user.name}</p>
      </div>
      <div className="text-right">
        <p className="font-bold text-xl text-emerald-500 dark:text-emerald-400">{user.greenUnits.toLocaleString()}</p>
        <p className="text-sm text-slate-500">GreenUnits</p>
      </div>
    </li>
  );
};

export default LeaderboardItem;