import React from 'react';

interface SpinnerProps {
    size?: 'sm' | 'md' | 'lg';
    message?: string;
}

const Spinner: React.FC<SpinnerProps> = ({ size = 'md', message }) => {
    const sizeClasses = {
        sm: 'h-8 w-8',
        md: 'h-16 w-16',
        lg: 'h-24 w-24',
    };

    return (
        <div className="flex flex-col items-center justify-center space-y-4">
            <div className={`animate-spin rounded-full border-4 border-t-4 border-slate-200 dark:border-slate-600 border-t-emerald-500 ${sizeClasses[size]}`}></div>
            {message && <p className="text-lg font-semibold text-emerald-600 dark:text-emerald-400">{message}</p>}
        </div>
    );
};

export default Spinner;