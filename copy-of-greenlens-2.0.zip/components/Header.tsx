import React from 'react';
import type { Page, User } from '../types';

interface HeaderProps {
  user: User;
  activePage: Page;
  onNavigate: (page: Page) => void;
  onLogout: () => void;
}

const Icon: React.FC<{ paths: string[]; className?: string }> = ({ paths, className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      {paths.map((d, i) => <path key={i} d={d} />)}
    </svg>
);

const ICONS = {
    home: <Icon paths={["M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z", "M9 22V12h6v10"]} />,
    dashboard: <Icon paths={["M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2", "M12 7a4 4 0 1 0 0-8 4 4 0 0 0 0 8z"]} />,
    leaderboard: <Icon paths={["M12 8c4 0 7-3.582 7-8a7 7 0 1 0-7 8zm0 0l-1.21 9.12L17 23l-5-3-5 3 1.21-9.12"]} />,
    map: <Icon paths={["M1 6v16l7-4 8 4 7-4V2l-7 4-8-4-7 4z", "M8 2v16", "M16 6v16"]} />,
    logout: <Icon paths={["M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4", "M16 17l5-5-5-5", "M21 12H9"]} />,
};


const Header: React.FC<HeaderProps> = ({ user, activePage, onNavigate, onLogout }) => {
  const navItems = [
    { id: 'home', label: 'Report Waste', icon: ICONS.home },
    { id: 'dashboard', label: 'My Dashboard', icon: ICONS.dashboard },
    { id: 'leaderboard', label: 'Leaderboard', icon: ICONS.leaderboard },
    { id: 'map', label: 'Waste Map', icon: ICONS.map },
  ];

  const getNavItemClasses = (page: Page) => {
    return `flex items-center space-x-2 px-3 py-2 rounded-lg transition-colors duration-200 ${
      activePage === page
        ? 'bg-emerald-500 text-white font-semibold shadow-md'
        : 'text-slate-600 dark:text-slate-300 hover:bg-emerald-100 dark:hover:bg-slate-700'
    }`;
  };

  return (
    <header className="bg-white/80 dark:bg-slate-800/80 backdrop-blur-lg sticky top-0 z-40 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <h1 className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">
              GreenLens
            </h1>
            <nav className="hidden md:flex ml-10 space-x-4">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id as Page)}
                  className={getNavItemClasses(item.id as Page)}
                  aria-current={activePage === item.id ? 'page' : undefined}
                >
                   <div className="h-5 w-5">{item.icon}</div>
                   <span>{item.label}</span>
                </button>
              ))}
            </nav>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-right">
                <p className="font-semibold text-slate-800 dark:text-slate-100">{user.name}</p>
                <p className="text-sm text-emerald-500 font-bold">{user.greenUnits.toLocaleString()} GreenUnits</p>
            </div>
            <img src={user.avatarUrl} alt={user.name} className="h-10 w-10 rounded-full" />
            <button
              onClick={onLogout}
              className="p-2 rounded-full text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-700"
              aria-label="Logout"
            >
              <div className="h-6 w-6">{ICONS.logout}</div>
            </button>
          </div>
        </div>
      </div>
       {/* Mobile Nav */}
       <nav className="md:hidden p-2 border-t border-slate-200 dark:border-slate-700 flex justify-around">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id as Page)}
                className={`flex flex-col items-center p-2 rounded-lg text-xs w-20 ${activePage === item.id ? 'text-emerald-500' : 'text-slate-500'}`}
                aria-current={activePage === item.id ? 'page' : undefined}
              >
                <div className="h-6 w-6 mb-1">{item.icon}</div>
                <span>{item.label}</span>
              </button>
            ))}
        </nav>
    </header>
  );
};

export default Header;