import React from 'react';
import type { Organization } from '../types';

interface OrgHeaderProps {
  org: Organization;
  onLogout: () => void;
}

const OrgHeader: React.FC<OrgHeaderProps> = ({ org, onLogout }) => {
  return (
    <header className="bg-white dark:bg-slate-800 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <h1 className="text-xl font-bold text-sky-600 dark:text-sky-400">
            {org.name} Portal
          </h1>
          <button
            onClick={onLogout}
            className="px-4 py-2 text-sm font-semibold bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-lg hover:bg-slate-300 dark:hover:bg-slate-600 transition-colors"
          >
            Logout
          </button>
        </div>
      </div>
    </header>
  );
};

export default OrgHeader;
