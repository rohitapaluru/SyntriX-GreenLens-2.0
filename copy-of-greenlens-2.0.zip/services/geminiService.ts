import { GoogleGenAI, Type } from "@google/genai";
import type { WasteType } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const result = reader.result as string;
      // remove 'data:image/...;base64,' prefix
      resolve(result.split(',')[1]);
    };
    reader.onerror = (error) => reject(error);
  });
};

interface AnalysisResult {
  isWastePresent: boolean;
  wasteType: WasteType;
  confidenceScore: number;
}

const analysisSchema = {
  type: Type.OBJECT,
  properties: {
    isWastePresent: {
        type: Type.BOOLEAN,
        description: "True if environmental waste is detected, false otherwise.",
    },
    wasteType: {
      type: Type.STRING,
      description: "The type of waste detected. Should be 'Other' if no waste is present.",
      enum: ['Plastic', 'Organic', 'E-waste', 'Metal', 'Glass', 'Paper', 'Other'],
    },
    confidenceScore: {
      type: Type.NUMBER,
      description: "A confidence score from 0 to 100 for the classification. Should be 0 if no waste is present.",
    },
  },
  required: ['isWastePresent', 'wasteType', 'confidenceScore'],
};

export const analyzeWasteImage = async (base64Image: string, mimeType: string): Promise<AnalysisResult> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: {
        parts: [
          {
            inlineData: {
              data: base64Image,
              mimeType: mimeType,
            },
          },
          {
            text: "First, determine if this image contains environmental waste (like litter, trash, etc.). If it does, classify the primary type of waste and provide a confidence score. If no waste is present, set isWastePresent to false, wasteType to 'Other', and confidenceScore to 0. Respond ONLY with the JSON object.",
          },
        ],
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: analysisSchema,
      },
    });
    
    const jsonString = response.text;
    const result = JSON.parse(jsonString);
    
    // Validate the result
    if (result && typeof result.isWastePresent === 'boolean' && typeof result.wasteType === 'string' && typeof result.confidenceScore === 'number') {
      return result as AnalysisResult;
    } else {
      console.error("Invalid analysis result format:", result);
      throw new Error("AI analysis returned an unexpected format.");
    }

  } catch (error) {
    console.error("Error analyzing image with Gemini API:", error);
    throw new Error("Failed to analyze image. Please try again.");
  }
};